let a = 3;
let b = 5;
let c;

let printingoutput = `let a = 3; \nlet b = 5; \nlet c;\n------- \n `;

printingoutput += `\na + b = ${ a + b }`;

printingoutput += `\na - b = ${ a - b }`;

printingoutput += `\na * b = ${ a * b }`;

printingoutput += `\na / b = ${ a / b }`;

printingoutput += `\na % b = ${ a % b }`;

printingoutput += `\na += b = ${ a += b }`;

printingoutput += `\na -= b = ${ a -= b }`;

printingoutput += `\na *= b = ${ a *= b }`;

printingoutput += `\na /= b = ${ a /= b }`;

printingoutput += `\na %= b = ${ a %= b }`;

printingoutput += `\na == b = ${ a == b }`;

printingoutput += `\na != b = ${ a != b }`;

printingoutput += `\na > b = ${ a > b }`;

printingoutput += `\na < b = ${ a < b }`;

printingoutput += `\n!a && !c = ${ !a && !c }`;

printingoutput += `\n!a || !c = ${ !a || !c }`;

alert(printingoutput);


//Task 2
/*Create the expression concatenating variables first_name, last_name, email and string literals needed to complete the sentence reading: "My name is Your-first-name Your-last-name. You can contact me at your-email@mail.com.";*/

let first_name = 'Balasankar';

let last_name  = 'Aravindakshan';

let email = 'arav0003@algonquinlive.com';

let output= `My name is ${first_name} ${last_name}.You can contact me at ${email}.`;

console.log(output);
